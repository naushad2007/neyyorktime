import './App.css';
import Routes from './Routes/Routes';
import { FooterContainer } from './Components/FooterContainer';


// import { LoginBottom } from './Components/LoginBottom';
function App() {
  return (
    < div className = "App">
      <Routes/>
      <FooterContainer />
 
    </div>

  );
}

export default App;
