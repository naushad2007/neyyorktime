import React from 'react'

const Section_latestSearch = () => {
    return (
        <div>
            
        </div>
    )
}

export default Section_latestSearch
